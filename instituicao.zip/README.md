# Sistema Institucional de Criação — Next.js Fullstack

> Um framework operacional para criar aplicações Next.js **sem improviso**, **com governança explícita** e **fluxo auditável**.

---

## Visão Geral

Este repositório fornece um **sistema institucional** (não apenas templates) para criação e evolução de aplicações **Next.js Fullstack**.

A proposta é simples:

- decisões arquiteturais são documentadas
- execução é guiada por playbooks
- validação é obrigatória
- evolução é controlada

Você **inicia fluxos**, não arquivos.

---

## O que este projeto resolve

- Ambiguidade arquitetural
- Retrabalho por decisões tardias
- Features fora de escopo
- Builds quebrados no meio do caminho
- Dependência de “memória tribal”

Tudo aqui é **explícito, rastreável e automatizável**.

---

## Como funciona (em 60 segundos)

1. **Dossiês** definem regras imutáveis (stack, arquitetura, princípios)
2. **Playbooks** executam tarefas em ordem correta
3. **Pipeline** valida cada entrega (design, build, arquitetura)
4. **Passaporte** descreve o produto antes de codar
5. **Orquestrador** decide o próximo passo

Nada acontece fora desse fluxo.

---

## Fluxo Oficial

```text
INICIAR PROJETO
  ↓
PLAYBOOK_CRIADOR
  ↓
PLAYBOOK_PIPELINE
  ↓
GERAR PASSAPORTE
  ↓
VALIDAR PASSAPORTE
  ↓
PLAYBOOK_EVOLUTOR (1 página por vez)
  ↓
PLAYBOOK_PIPELINE
  ↓
(repetir até concluir)
```

---

## Estrutura Institucional

```text
/institucional
├── 00-mapa-geral/
├── 01-dossies/
├── 02-playbooks/
├── 03-passaporte/
├── 04-agentes/
├── 05-referencias/
└── 06-historico/
```

Cada pasta tem um papel claro. Nenhuma é opcional.

---

## Regras Essenciais

- Nenhuma feature sem Passaporte
- Nenhuma execução sem Playbook
- Nenhum código fora do Pipeline
- Uma página fechada por vez

Se algo não puder avançar, o sistema **bloqueia e pede decisão humana**.

---

## Para quem é

- Times que usam Next.js Fullstack
- Projetos que precisam de previsibilidade
- Ambientes que exigem auditoria
- Quem quer escalar sem caos

---

## O que isto **não** é

- Não é boilerplate
- Não é gerador de código mágico
- Não é framework de UI
- Não substitui decisão de produto

---

## Licença e Uso

Este projeto pode ser usado como:

- base institucional interna
- framework operacional
- referência para automação com agentes

Adapte os documentos ao seu contexto, **não quebre a hierarquia**.

---

## Começar agora

Leia nesta ordem:

1. `MAPA_INSTITUCIONAL.md`
2. `DOSSIE_REGRAS_DE_CRIACAO.md`
3. `PLAYBOOK_CRIADOR.md`

Depois disso, você já consegue iniciar um projeto com segurança.

---

## Princípio Final

> Não é sobre escrever código mais rápido.
>
> É sobre **errar menos, decidir melhor e evoluir com segurança**.
