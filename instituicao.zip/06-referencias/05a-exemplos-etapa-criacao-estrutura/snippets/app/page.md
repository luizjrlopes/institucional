# Codigo do arquivo app/page.tsx

```typescript
import Main from "./Main";

export default function HomePage() {
  return <Main />;
}
```
